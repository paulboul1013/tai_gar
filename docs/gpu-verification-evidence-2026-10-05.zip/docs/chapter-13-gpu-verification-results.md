# Chapter 13 實作與驗證結果

日期：2026-10-05。依據 [GPU 驗證研究](chapter-13-gpu-verification-research.md) 實作。
設定政策、瀏覽器整合、診斷、量測／分析工具及獨立 code review 已完成；完整 GPU 驗收尚未通過。
重現方式見 [操作文件](chapter-13-gpu-verification-usage.md)。

| 獨立判定 | 本環境結果 | 依據 |
| --- | --- | --- |
| `gl_path_status` | PENDING | 實際 GL raster 可執行；缺少 L2 call trace、完整凍結畫面 gate、DPI transition 及可核對的最小化事件 |
| `hardware_status` | FAIL | Tai Gar 自己的 current context 回報已知 software renderer：llvmpipe |
| `performance_status` | PENDING | 主場景資格未達標、校準未凍結，因此沒有啟動正式配對效能實驗 |

PASS 的單元測試、預期拒絕、部分生命週期操作與畫面相等，均沒有提升上述三項判定。

## 交付內容

- `gpu_evidence.py`：保留原始設定、明確拒絕非法配置、嚴格 renderer 政策、程序／native thread／context／frame 身分、時鐘錨點、獨立 gates 及原子匯出。
- `browser.py`：GL owner 與 current context 檢查、實際 attributes／drawable／renderer、navigation／scene 世代、因果輸入與 present 返回時間、正常及失效 context 的分別清理。正常 GPU frame 不 readback。
- `gpu_query.py`：optional、有界 query ring，先檢查 availability，再讀完整 64-bit 結果；失效 context 不呼叫 GL。
- `gpu_workload.py`：四個固定的真實 DOM／CSS／JS fixtures；snapshot／geometry／font 身分，交替狀態確實重新 raster 並改變畫面。
- `gpu_verification.py`：prepare、qualify、replay、正常互動、capture、query、嚴格負例、校準／比較／freeze、正式 runner、重算、OS worksheet 及可攜 raw bundle。
- `gpu_analysis.py`：完整矩陣與公平性核對、paired block bootstrap、吞吐及產品 p95 門檻、分區與 8×8 tiles 畫面比較、負例及凍結 hash。
- `tests/`：設定、生命週期、真實 JS bridge／CPU raster、query、統計／負例及 CLI 證據契約；另有 opt-in 的實際開窗生命週期腳本。

Replay 直接使用真實瀏覽器的 raster／composition 路徑；固定 fixture 的 chrome display list 為空。
完整正常互動另走實際頁面載入與 Browser pipeline，兩種量測範圍在 raw run 中分開記錄。

## 實際驗證

環境：Linux WSL2，kernel `6.18.40.1-microsoft-standard-WSL2`；Python 3.12.3、
skia-python 144.0.post2、PySDL2 0.9.17／SDL 2.32.10、PyOpenGL 3.1.10、NumPy 2.4.1。
實際 context：vendor `Mesa`，renderer `llvmpipe (LLVM 20.1.2, 256 bits)`，
version `4.5 (Core Profile) Mesa 25.2.8-0ubuntu0.24.04.2`。

| 檢查 | 結果與範圍 |
| --- | --- |
| 完整 headless suite | 129 項 PASS，包含 Chapter 12 回歸；raw log 保存於證據包 |
| 最後一輪 smoke | 四場景 × CPU sync／GPU sync／CPU threaded，12 個獨立程序全部 `ok`；每 run 2 warmup／4 measured frames，全部是 diagnostic |
| `small` capture | CPU／GL 的兩個狀態均為 600×800×4，逐像素完全相等；各 run 讀回 3 次，包含兩個狀態及最後畫面 |
| GL query | 真實 context 取得 360 個 64-bit samples；首個暖機 sample 異常偏大，原始值保留、未推定原因，不能作正式速度資料 |
| hardware strict 負例 | 預期拒絕 software renderer，沒有建立 Skia GL 路徑或切 CPU；原始 hardware FAIL 與負例斷言分開 |
| 正常 GL／CPU threaded 互動 | 各取得 300 measured frames、100 個可歸因輸入效果；沒有 capture／query／readback，不作正式效能 PASS 判定 |
| 正式 run gate | 未資格化／未校準的 manifest 被拒絕，exit 1，沒有建立正式輸出目錄 |

主場景 `text_rect` 本次資格資料的 renderer fraction 為 **31.20%**，低於事先規定的 50%。
Raw 保存兩個真正 CPU raster、不同 pixel hashes 及 main style／layout／paint preparation timings；
工具從 raw 重算 fraction，拒絕只提供 summary。其他早期資格結果也保留。
這是資格檢查，沒有主場景正式速度結果，也沒有依速度結果追加樣本或調整負載。

實際生命週期腳本的結果如下；故障注入有獨立斷言，原始診斷仍保存預期停止。

| 操作 | 結果 |
| --- | --- |
| 雙窗口 context 切換、resize | PASS |
| 切 tab／navigation、提交繪圖後關窗 | PASS |
| 初始化失敗清理、context loss 停止及 abandon 清理 | PASS |
| DPI transition | PENDING：本輪沒有取得實際 DPI 變化 |
| 最小化／恢復 | PENDING：WSLg 未提供本測試可核對的最小化事件 |

## 獨立審查與修正

三位 subagent 分工審查 evidence／query／workload、analysis，以及 browser lifecycle／CLI；
並以另一套測試核對實際 CPU raster、JS bridge、64-bit query 及原始證據綁定。
修正後最後一輪 reviewer 報告為 129 tests PASS，沒有剩餘 blocker。

審查與實測修正了 snapshot hash 漏 geometry、無關 font cache 影響身分、
drawable 重建前未切 current context、重複 dirty mutation 漏 input ID、
初始化例外清理、失效 context 的 present、worker crash／exit 的錯誤分類，
以及 summary 冒充完整 frozen proof 等問題。
真實 PyOpenGL 的自動 uint64 converter 也曾失敗；改用明確 `ctypes.c_uint64` buffer 後重跑成功。
失敗原始資料一併保留，沒有刪除再計成 PASS。

整理 README 時曾改變已建立 manifest 的未提交 diff hash，該批 12 runs 被判為
`measurement_fault`，未進正式統計。最後交付 smoke 使用新的 manifest，12 runs 全部成功。
早期診斷與最後版本在資料目錄中分開保存；其不同 program identity 不被混成同一正式實驗。

## 原始證據與尚未完成的驗收

下載 [證據包](gpu-verification-evidence-2026-10-05.zip)。內含最後 smoke 的 source、完整未提交 diff、
manifest、raw runs／frames／logs／summary、資格資料、capture pixels、query／strict 負例、
正常互動及生命週期 raw evidence、完整測試 log、審查紀錄、早期失敗資料與 SHA-256 checksums。
`artifact-index.json` 將原始絕對路徑映射到包內路徑；原始 JSON 不被改寫。
解壓後可依操作文件從最後 smoke 的 manifest／runs 重算 summary；它應仍為 PENDING／FAIL／PENDING。

完整結案還需要：事前資格化的新主場景與新 manifest、四場景完整凍結的分區容差及五類負例、
L2 GL call evidence、實際 DPI／最小化驗證、可歸因到 Tai Gar 程序／context 的 L3 原始硬體證據，
以及符合既定順序／樣本數的正式配對實驗。
本輪沒有安裝選用 apitrace，也沒有修改 driver 或 WSLg 設定；OS worksheet 保持待填狀態。
目前環境的 llvmpipe 結果不能支持硬體加速或效能改善的主張。

Tai Gar Chapter 13 evidence, 2026-10-05.
Final verdict: gl_path PENDING; hardware FAIL (actual llvmpipe); performance PENDING.
final-smoke is 12 diagnostic runs, not a formal paired performance experiment.
final-diagnostics contains current-version raw records; earlier directories retain failures and other program identities.
DPI/minimize, full frozen image calibration, L2 calls and L3 hardware attribution remain incomplete.
The first warmup GL query sample is anomalously large and retained without an inferred cause.
Original JSON files and absolute paths are preserved; use artifact-index.json to find archive files.
The uncommitted diff includes pre-existing user changes and is not a change-only diff for this task.
The earlier work sheet mentioned a /tmp pre-implementation backup that is unavailable at packaging time; it is not included or reconstructed.
Source and review/test passes establish implementation scope, not full GPU acceptance.
To recompute smoke summary, run gpu_verification.py analyze with final-smoke/manifest.json and final-smoke/runs.json.
checksums.json covers all members except itself.

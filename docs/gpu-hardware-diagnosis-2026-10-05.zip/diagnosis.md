# AMD／WSLg 硬體選擇診斷

日期：2026-10-05。這是首次 llvmpipe 測試之後的獨立診斷，沒有正式效能結果。

先前沒有使用實體 GPU 的直接原因是：預設 Mesa OpenGL context 選到了
`llvmpipe (LLVM 20.1.2, 256 bits)`。預設 `glxinfo -B` 在沙箱外也回報
`Accelerated: no`，沒有發現 `LIBGL_ALWAYS_SOFTWARE` 等強制軟體渲染設定。
尚未確定 Mesa 自動選擇 llvmpipe 的更底層原因。

沙箱外存在 `/dev/dxg`、WSL 的 D3D12／DXCore libraries 與 AMD user-mode driver；
Windows 回報 `AMD Radeon(TM) Graphics`、driver `30.0.13014.8`、Status `OK`。
沙箱內沒有看見 `/dev/dxg`，因此不能以沙箱內裝置列表推定 Windows GPU 不可用。

只在診斷程序設定 `GALLIUM_DRIVER=d3d12` 後，`glxinfo -B` 回報
`D3D12 (AMD Radeon(TM) Graphics)`、`Accelerated: yes`。
這個對照證明硬體後端可被選到；沒有修改永久環境變數、driver 或 WSLg 設定。

隔離探針在實際 GLX context 上完成三幀 `glClear`／`glFinish`／swap；
Skia import、GLX interface validation、預設 `GrDirectContext.MakeGL()`、
明確 GLX interface 的 `MakeGL(interface)` 四個獨立程序都 exit 0。
這些探針沒有執行完整 Tai Gar raster，也不是硬體效能驗收。

完整 Tai Gar `small`／`gpu_sync`／strict diagnostic 在相同 D3D12 設定下，
兩次都已記錄自己的 AMD GL context，但隨後 SIGSEGV（shell exit 139），
兩次 raw run 的 `frames` 均為空，初始狀態保留為 `product_failure`。
原生崩潰沒有經過 Python 清理／例外處理，因此 JSON 沒有完整失敗原因。
不得將這些 runs 計為 PASS 或正式速度樣本。

GDB 曾觀察到 driver worker thread 的 stack 經過 `libd3d12core.so`、
`_Unwind_RaiseException`、`__cxa_throw` 與 AMD `amdxc64.so`。
這是現場觀察筆記，當次 GDB 輸出未保存為 raw 檔案；它不足以證明是哪個元件的 bug，
也不足以將 `MakeGL()` 或任何 driver 更新判為確定原因／修復。
完整流程與隔離探針的差異仍需定位。

下載 [診斷原始資料](gpu-hardware-diagnosis-2026-10-05.zip)。內含 manifest、
兩次失敗 run／evidence／trace、隔離探針及各程序輸出、driver 載入 strace 與 checksums。
shell exit 139 與 GDB stack 是上述現場筆記，不冒充 raw JSON 中已有的欄位。
原 [v1 證據包](gpu-verification-evidence-2026-10-05.zip) 保持不變。

目前結論：預設後端選擇已解釋先前的 CPU 軟體渲染；AMD 基本 GL 可運作，
完整 Tai Gar 硬體路徑仍有未解的原生崩潰，尚未完成硬體加速驗收。

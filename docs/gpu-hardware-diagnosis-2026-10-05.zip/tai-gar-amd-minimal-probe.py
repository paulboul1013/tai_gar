import argparse
import ctypes
import json
import os
from pathlib import Path
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=['matrix', 'gl-only', 'skia-import', 'skia-interface', 'skia-native', 'skia-glx'])
args = parser.parse_args()
if args.mode == 'matrix':
    results = []
    for mode in ('skia-import', 'skia-interface', 'skia-native', 'skia-glx'):
        result = subprocess.run([sys.executable, '-B', '-u', __file__, mode], capture_output=True, text=True, timeout=30)
        record = dict(mode=mode, exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr)
        results.append(record)
        print(json.dumps(record), flush=True)
    Path('/tmp/tai-gar-amd-minimal-matrix.json').write_text(json.dumps(results, indent=2) + '\n')
    raise SystemExit(0)
if args.mode != 'gl-only':
    import skia
import sdl2
from OpenGL import GL

def checkpoint(phase, **value):
    print(json.dumps(dict(phase=phase, mode=args.mode, **value)), flush=True)

assert sdl2.SDL_Init(sdl2.SDL_INIT_VIDEO) == 0
for attribute, value in [(sdl2.SDL_GL_CONTEXT_MAJOR_VERSION, 3),
    (sdl2.SDL_GL_CONTEXT_MINOR_VERSION, 3),
    (sdl2.SDL_GL_CONTEXT_PROFILE_MASK, sdl2.SDL_GL_CONTEXT_PROFILE_CORE),
    (sdl2.SDL_GL_RED_SIZE, 8), (sdl2.SDL_GL_GREEN_SIZE, 8),
    (sdl2.SDL_GL_BLUE_SIZE, 8), (sdl2.SDL_GL_ALPHA_SIZE, 8),
    (sdl2.SDL_GL_STENCIL_SIZE, 8), (sdl2.SDL_GL_MULTISAMPLEBUFFERS, 0),
    (sdl2.SDL_GL_MULTISAMPLESAMPLES, 0), (sdl2.SDL_GL_DOUBLEBUFFER, 1)]:
    assert sdl2.SDL_GL_SetAttribute(attribute, value) == 0
window = sdl2.SDL_CreateWindow(b'Tai Gar temporary GPU probe', 100, 100, 300, 150, sdl2.SDL_WINDOW_OPENGL)
assert window
context = sdl2.SDL_GL_CreateContext(window)
assert context
assert sdl2.SDL_GL_MakeCurrent(window, context) == 0
checkpoint('current_context', renderer=GL.glGetString(GL.GL_RENDERER).decode(), version=GL.glGetString(GL.GL_VERSION).decode())
glx = ctypes.CDLL('libGL.so.1')
glx.glXGetCurrentContext.restype = ctypes.c_void_p
egl = ctypes.CDLL('libEGL.so.1')
egl.eglGetCurrentContext.restype = ctypes.c_void_p
api = 'glx' if glx.glXGetCurrentContext() else 'egl' if egl.eglGetCurrentContext() else None
checkpoint('current_api', api=api)
skia_context = None
if args.mode == 'skia-native':
    checkpoint('before_make_gl')
    skia_context = skia.GrDirectContext.MakeGL()
elif args.mode in ('skia-interface', 'skia-glx'):
    checkpoint('before_interface')
    interface = skia.GrGLInterface.MakeGLX() if api == 'glx' else skia.GrGLInterface.MakeEGL()
    checkpoint('interface', present=interface is not None, valid=interface.validate() if interface else False)
    if args.mode == 'skia-glx':
        checkpoint('before_make_gl')
        skia_context = skia.GrDirectContext.MakeGL(interface)
if args.mode in ('skia-native', 'skia-glx'):
    assert skia_context is not None
    checkpoint('skia_context', backend=str(skia_context.backend()))
for index in range(3):
    GL.glClearColor(0.2, 0.5, 0.8, 1.0)
    GL.glClear(GL.GL_COLOR_BUFFER_BIT)
    GL.glFinish()
    sdl2.SDL_GL_SwapWindow(window)
    checkpoint('completed_frame', index=index)
    sdl2.SDL_Delay(50)
if skia_context is not None:
    skia_context.releaseResourcesAndAbandonContext()
sdl2.SDL_GL_DeleteContext(context)
sdl2.SDL_DestroyWindow(window)
sdl2.SDL_Quit()
checkpoint('clean_shutdown')
